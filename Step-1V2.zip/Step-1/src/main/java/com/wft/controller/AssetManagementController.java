package com.wft.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.wft.service.AssetService;

@Controller
public class AssetManagementController {
	
	
	@Autowired
	private AssetService assetService;
	
	@RequestMapping(value = "/addEmployee", method = RequestMethod.GET)
	public String showAddEmployeePage() {
		return "addEmployee";
	}
	
	@RequestMapping(value = "/assetList", method = RequestMethod.GET)
	public String showAssetListPage() {
				return "assetList";
	}
	
	 @RequestMapping(value = "/assetList", method = RequestMethod.POST)
		public String showAssetList(ModelMap model, @RequestParam String searchAssetId,
				@RequestParam String searchEmployeeId) {

		 model.addAttribute("asset", assetService.getAllAsset(searchEmployeeId));

			return "assetList";
		}
	
	@RequestMapping(value = "/addAsset", method = RequestMethod.GET)
	public String showAddAssetPage() {
		return "addAsset";
	}
}
