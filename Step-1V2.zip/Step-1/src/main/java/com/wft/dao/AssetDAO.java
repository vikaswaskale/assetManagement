package com.wft.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.wft.model.Asset;

@Component
public class AssetDAO {

	public List<Asset> getAllassets(String employeeId) {

		
     List<Asset> assetList = new ArrayList<Asset>();
    
     if (employeeId != null) {
	     Asset asset = new Asset();
	     asset.setAssetId("2345");
	     asset.setModelName("Laptop");
	     
	     Asset asset1 = new Asset();
	     asset1.setAssetId("908");
	     asset1.setModelName("Desktop");
	 
	     
	     assetList.add(0, asset);
	     assetList.add(1, asset1);
     }
     return assetList;
     
     
    }
	
	
}
