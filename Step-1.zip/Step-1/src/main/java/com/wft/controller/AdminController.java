package com.wft.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AdminController {
	
	
	
	@RequestMapping(value = "/addEmployee", method = RequestMethod.GET)
	public String showAddEmployeePage() {
		return "addEmployee";
	}
	
	@RequestMapping(value = "/assetList", method = RequestMethod.GET)
	public String showAssetListPage() {
		return "assetList";
	}
	
	@RequestMapping(value = "/addAsset", method = RequestMethod.GET)
	public String showAddAssetPage() {
		return "addAsset";
	}
	/*
	 * @RequestMapping(value = "/login", method = RequestMethod.POST) public String
	 * handleUserLogin(ModelMap model, @RequestParam String uname,
	 * 
	 * @RequestParam String psw) {
	 * 
	 * if (!loginService.validateUser(uname, psw)) { model.put("errorMessage",
	 * "Invalid Credentials"); return "login"; }
	 * 
	 * model.put("uname", uname); return "welcome"; }
	 * 
	 * @RequestMapping(value = "/logout", method = RequestMethod.GET) public String
	 * logout(HttpServletRequest request, HttpServletResponse response) {
	 * 
	 * Authentication auth = SecurityContextHolder.getContext()
	 * .getAuthentication();
	 * 
	 * if (auth != null) { new SecurityContextLogoutHandler().logout(request,
	 * response, auth); request.getSession().invalidate(); } return
	 * "redirect:/assetManagement/login"; }
	 */
}
